CONFIG = {
    URL: "https://mhgray.github.io/LD52Phlip/main.html",
    INTROTEXT: "It is I, Chicky, the girl you love and have always loved. Unfortunately for you, I do not love you right now. " +
        "However, if you manage to collect $10000 sweet dollars and become slightly richer, I WILL love you, oh yes I will. " +
        "I know you love to haggle, so I have some items for you to start haggling for me. See you soon uwu. " +
        "Oh by the way if you don't do this in a month I will find another person to love, so hurry up and harvest money for my love.",
    WINTEXT: "Oh my GOOOOOOD, YOU'VE DONE IT. You harvested $10000 and have gotten my love. My undying love. My " +
        "eternal affection. I will never forget this day. Thanks for the money. If you collect $10000 more we can maybe" +
        " go out together. Who knows. Wink wink. I just hope you can manage that much ;)",
    LOSETEXT: "Fuck you, you stupid useless haggler. I don't need you. You're worthless. You will never have my love. My love" +
        " is reserved for people who are GOOD at what they do, not for dummies like you. I hope you never haggle again in your life." +
        " I will have to keep this money here just to pay for the psychological damages you've caused me... However, if you managed to " +
        "harvest $10000, I may forgive you and love you... I don't know tho, go try again."
}