let Button = function(args){
  this.x = args.x;
  this.y = args.y;
  this.width = args.width;
  this.height = args.height;
  this.image = args.image;
  this.text = args.text;

  this.update = function(){

  }

  this.draw = function(){

  }
}
