let Item = function(){
    this.x = 0;
    this.y = 0;
    this.name = "";
    this.quality = 0;
    this.baseVal = 0;
    this.apparentVal = 0;
    this.type = "";
    this.description = "";
    this.specialFlag = "";

    this.update = function(){

    }

    this.draw = function(){

    }

}

